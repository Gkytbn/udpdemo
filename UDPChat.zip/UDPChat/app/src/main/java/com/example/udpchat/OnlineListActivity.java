package com.example.udpchat;

import java.util.Map;
import java.util.TreeMap;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.entity.Msg;
import com.example.net.UdpSender;

/**
 * 在线好友列表的界面，提供刷新功能。
 * @author dxd
 * 20140312
 */
public class OnlineListActivity extends Activity {
	private Button but ;
	private ListView list ;
	private SimpleAdapter adapter ;
	private MyHandler mHandler ;
	private ProgressDialog dialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.act_onlinelist);
		initView();
		setListener();
	}
	
	private void initView(){
		but = (Button) findViewById(R.id.but_refresh);
		list = (ListView)findViewById(R.id.list);
		adapter = new SimpleAdapter(this ,
				App.getOnlineFriends() ,
				R.layout.frienditem ,
				new String[]{"name","ip"} ,
				new int[]{R.id.name ,R.id.ip}
				);
		list.setAdapter(adapter);
		mHandler = new MyHandler();
		App.setHandler(mHandler);
		App.setContext(OnlineListActivity.this);
	}
	
	private void setListener(){
		but.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				refresh();
			}
		});
		list.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,long id) {
				Map<String,String> map = new TreeMap<String,String>();
				map = App.getOnlineFriends().get(position);
				if(null == map){
					return ;
				}
				Intent intent = new Intent(OnlineListActivity.this,ChatActivity.class);
				intent.putExtra("name", map.get("name"));
				intent.putExtra("ip", map.get("ip"));
				OnlineListActivity.this.startActivity(intent) ;
			}
		});
	}
	
	@SuppressLint("HandlerLeak")
	class MyHandler extends Handler {
		@Override
		public void handleMessage(Message msg) {
			switch(msg.what){
			case 1:
				adapter = new SimpleAdapter(OnlineListActivity.this ,
					App.getOnlineFriends() ,
					R.layout.frienditem ,
					new String[]{"name","ip"} ,
					new int[]{R.id.name ,R.id.ip});
				list.setAdapter(adapter);
				break ;
			case 2 :
				if(null != dialog && dialog.isShowing()){
					dialog.cancel() ;
				}
				adapter = new SimpleAdapter(OnlineListActivity.this ,
					App.getOnlineFriends() ,
					R.layout.frienditem ,
					new String[]{"name","ip"} ,
					new int[]{R.id.name ,R.id.ip});
				list.setAdapter(adapter);
				break ;
			}
			super.handleMessage(msg);
		}
	}
	
	public void refresh(){
		// 发送广播，收集在线好友
		App.removeAllFriends();
		Msg msg = new Msg();
		msg.setmName(App.getName());
		msg.setmIp("255.255.255.255");//广播地址
		msg.setmPort(App.mListenPort);
		msg.setmContent("");
		msg.setmType(Msg.TYPE_ONLINE);
		UdpSender.send(msg);
		dialog = new ProgressDialog(OnlineListActivity.this);
		dialog.setTitle("正在搜索") ;
		dialog.show();
		mHandler.sendEmptyMessageDelayed(2, 1000) ;
	}
}
