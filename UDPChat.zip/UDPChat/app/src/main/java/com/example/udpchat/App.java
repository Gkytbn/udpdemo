package com.example.udpchat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.example.entity.Msg;
import com.example.net.UdpReceiver;
import com.example.net.UdpReceiver.IReceiveListener;
import com.example.net.UdpSender;
import com.example.util.TimeReader;

/**
 * Application伴随apk的生命周期，这里可以提供一些数据进行共享
 * @author dxd
 * 20140312
 */
public class App extends Application {
	public static int mListenPort = 9521;
	private static List<Map<String,String>> mOnlineFriends ;
	private static String mName ;
	private static String mCurrentChatName = "1234567921313213213";// 默认一个值
	private static Context mContext ;

	@Override
	public void onCreate() {
		mOnlineFriends = new ArrayList<Map<String,String>>();
		super.onCreate();
	}

	public static void setContext(Context context){
		mContext = context ;
	}
	
	private static Handler mHandler ;
	
	public static String getCurrentChatName(){
		return mCurrentChatName ;
	}
	
	public static void setCurrentChatName(String name){
		mCurrentChatName = name ;
	}
	
	public static void setHandler(Handler handler){
		mHandler = handler ;
	}
	
	
	public static void setName(String name){
		mName = name ;
	}
	
	public static String getName(){
		return mName ;
	}
	
	public static void removeAllFriends(){
		mOnlineFriends.removeAll(mOnlineFriends);
	}
	
	public static List<Map<String,String>> getOnlineFriends(){
		return mOnlineFriends ;
	}
	public static void startListenPort() {
		UdpReceiver.startReceive(mListenPort, new IReceiveListener() {
			@Override
			public void receivedMsg(final Msg netMsg) {
				if (null == netMsg) {
					return;
				}
				final String ip = netMsg.getmIp() ;
				final String name = netMsg.getmName() ;
				String type = netMsg.getmType();
				
				if (type.equals(Msg.TYPE_NOMAL)) { // 一般的文字消息
					Log.e("","收到nomal消息了");
					// 通知有消息来，这才是可见消息
					final Context bigContext = mContext.getApplicationContext() ;
						Log.e("","发送广播");
						//发送广播即可
						Intent intent = new Intent("com.example.udpchat.friendchange");
						Bundle b = new Bundle();
						b.putParcelable("msg", netMsg);
						intent.putExtras(b);
						bigContext.sendBroadcast(intent);
				} else if (type.equals(Msg.TYPE_ONLINE)) { // 收到上线消息
					Log.e("IReceiveListener","一个client上线了，name = " + name);
					if(name.equals(mName)){
						Log.e("IReceiveListener","自己上线，不用应答");
						return;
					}
					Map<String,String> map = new TreeMap<String,String>();
					map.put("name", name);
					map.put("ip", ip);
					if(!mOnlineFriends.contains(map)){
						mOnlineFriends.add(map);
					}
					// 把自己的name发送给请求方
					Msg newMsg = new Msg();
					newMsg.setmName(mName);
					newMsg.setmIp(ip);// 目标IP
					newMsg.setmPort(mListenPort);// 目标监听的端口号
					newMsg.setmContent("");
					newMsg.setmType(Msg.TYPE_RESPONSE); // 表示我回应给对方的消息
					newMsg.setmDate(TimeReader.getDate()) ;
					UdpSender.send(newMsg);
					if(null != mHandler)
						mHandler.sendEmptyMessage(1);
				} else if (type.equals(Msg.TYPE_OUTLINE)) { // 收到下线消息
					Log.e("IReceiveListener","收到一个outline消息，name = " + name);
					if(name.equals(mName)){
						Log.e("IReceiveListener","是我自己下线了。");
					}
					Map<String,String> map = new TreeMap<String,String>();
					map.put("name", name);
					map.put("ip", ip);
					mOnlineFriends.remove(map) ;
					if(null != mHandler)
						mHandler.sendEmptyMessage(1);
				} else if (type.equals(Msg.TYPE_RESPONSE)) { // 收到回复上线消息的消息
					Log.e("IReceiveListener","收到一个respose消息，name = " + name);
					Map<String,String> map = new TreeMap<String,String>();
					map.put("name", name);
					map.put("ip", ip);
					if(!mOnlineFriends.contains(map)){
						mOnlineFriends.add(map);
						if(null != mHandler)
							mHandler.sendEmptyMessage(1);
					}
				}
			}

			@Override
			public void occuredException(String exStr) {
				Log.e("IReceiveListener","occuredException");
			}
		});
	}
}
