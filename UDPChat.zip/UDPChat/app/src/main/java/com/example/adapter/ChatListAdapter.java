package com.example.adapter;

import java.util.List;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.entity.Msg;
import com.example.udpchat.App;
import com.example.udpchat.R;

/**
 * 聊天消息左右罗列的adapter
 * @author dxd
 * 20140312
 */
public class ChatListAdapter extends BaseAdapter {
	private Context cxt;
	private LayoutInflater inflater;
	private List<Msg> listMsg;

	public ChatListAdapter(Context formClient, List<Msg> list) {
		this.cxt = formClient;
		listMsg = list;
	}

	@Override
	public int getCount() {
		return listMsg.size();
	}

	@Override
	public Object getItem(int position) {
		return listMsg.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		this.inflater = (LayoutInflater) this.cxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		Msg msg = listMsg.get(position) ;
		// 这里做的判断：自己发送的消息显示在右边，别人发送过来的消息显示在左边
		if (msg.getmName() != null && msg.getmName().equals(App.getCurrentChatName())) {
			convertView = this.inflater.inflate(R.layout.formclient_chat_in,null);
		} else {
			convertView = this.inflater.inflate(R.layout.formclient_chat_out,null);
		}

		TextView useridView = (TextView) convertView.findViewById(R.id.formclient_row_userid);
		TextView dateView = (TextView) convertView.findViewById(R.id.formclient_row_date);
		TextView msgView = (TextView) convertView.findViewById(R.id.formclient_row_msg);
		useridView.setText(msg.getmName());
		dateView.setText(listMsg.get(position).getmDate());
		msgView.setText(msg.getmContent());
		return convertView;
	}
}