package com.example.udpchat;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.adapter.ChatListAdapter;
import com.example.entity.Msg;
import com.example.net.UdpSender;
import com.example.util.TimeReader;

/**
 * 聊天界面，必须双方同时打开与对方聊天的界面，才能收到彼此的消息
 * @author dxd
 * 20140312
 */
public class ChatActivity extends Activity {
	private EditText et_text ;
	private Button but_send ;// 连接按钮
	private TextView tv ;
	private String targetName ;
	private String targetIp ;
	private ListView mChatList ;
	private List<Msg> mList ;
	private ChatListAdapter mAdapter ;
	private ChatBroadcastReceiver mReceiver ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.act_chat);
		Intent intent = this.getIntent();
		targetName = intent.getStringExtra("name") ;
		targetIp = intent.getStringExtra("ip") ;
		App.setCurrentChatName(targetName);
		//Log.e("","获取了：" +  targetName + "    " +  targetIp);
		initView();
		setListener();
		mReceiver = new ChatBroadcastReceiver() ;
		IntentFilter filter = new IntentFilter();  
	    filter.addAction("com.example.udpchat.friendchange") ;  
	    registerReceiver(mReceiver, filter) ;
	}
	
	private void initView(){
		tv = (TextView)findViewById(R.id.chat_titel);
		tv.setText("与 " + targetName + " : " + targetIp + " 聊天中" ) ;
		but_send = (Button)findViewById(R.id.but_send);
		mChatList = (ListView)findViewById(R.id.chat_list) ;
		et_text = (EditText)findViewById(R.id.et_text);
		mList = new ArrayList<Msg>();
		mAdapter = new ChatListAdapter(this, mList);
		mChatList.setAdapter(mAdapter);
	}
	private void setListener(){
		but_send.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				String text = et_text.getText().toString() ;
				if(text ==  null || text.length() <= 0 ){
					Toast.makeText(ChatActivity.this, "请输入发送内容", Toast.LENGTH_SHORT).show() ;
					return ;
				}
				Msg targetMsg = new Msg();
				targetMsg.setmContent(text);
				targetMsg.setmName(App.getName());
				targetMsg.setmIp(targetIp);
				targetMsg.setmType(Msg.TYPE_NOMAL);
				targetMsg.setmPort(App.mListenPort);
				targetMsg.setmDate(TimeReader.getDate());
				UdpSender.send(targetMsg);
				mList.add(targetMsg);
				mAdapter.notifyDataSetChanged();
				et_text.setText("");
			}
		});
	}
	
	class ChatBroadcastReceiver extends BroadcastReceiver{
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction() ;
			Log.e("ChatBroadcastReceiver","------收到广播 , " + action);
			if(action.equals("com.example.udpchat.friendchange")){//
				Msg msg = intent.getParcelableExtra("msg");
				if(null != msg){
					mList.add(msg);
					mAdapter.notifyDataSetChanged();
				}
			}
		}
	}
	
	@Override
	public void finish() {
		App.setCurrentChatName("12313213213213");
		unregisterReceiver(mReceiver);
		super.finish();
	}
}
