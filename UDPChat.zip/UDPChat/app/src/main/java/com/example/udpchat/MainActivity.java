package com.example.udpchat;

import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.entity.Msg;
import com.example.net.UdpReceiver;
import com.example.net.UdpSender;

/**
 * 主界面，输入用户名，并且连接
 * @author dxd
 * 20140312
 */
public class MainActivity extends Activity {
	private EditText et ;
	private Button but ;// 连接按钮
	private ProgressDialog dialog ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		findView();
		setListener();
	}
	
	private void findView(){
		et = (EditText)findViewById(R.id.et);
		but = (Button)findViewById(R.id.but);
		dialog = new ProgressDialog(MainActivity.this);
		dialog.setTitle("正在搜索");
	}

	private void setListener(){
		but.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				String name = et.getText().toString();
				if(null == name){
					Toast.makeText(MainActivity.this, "名字不能为空", Toast.LENGTH_SHORT).show();
					return ;
				}
				App.setName(name);
				App.startListenPort();
				Log.e("","name = " + name);
				// 开始发送广播，等待回应
				Msg msg = new Msg();
				msg.setmName(name);
				msg.setmIp("255.255.255.255");//广播地址
				msg.setmPort(App.mListenPort);
				msg.setmContent("");
				msg.setmType(Msg.TYPE_ONLINE);
				UdpSender.send(msg);
				dialog.show();
				// 2秒钟跳转到发现好友的列表
				new MyHandler().sendEmptyMessageDelayed(1, 2000);
			}
		});
	}
	
	@SuppressLint("HandlerLeak")
	class MyHandler extends Handler{
		@Override
		public void handleMessage(Message msg) {
			dialog.cancel();
			
			List<Map<String ,String>> list = App.getOnlineFriends() ;
			if(null == list || 0 <= list.size()){
				// 在提示搜索的结果时，有时会出错。可能是搜索时间不够
				Toast.makeText(MainActivity.this, "没有搜索到！", Toast.LENGTH_SHORT).show();
				//Log.e("","list" + list.size());
				//return ;
			}
			Intent intent = new Intent(MainActivity.this ,OnlineListActivity.class);
			startActivity(intent);
			super.handleMessage(msg);
		}
	}
	
	@Override
	protected void onDestroy() {
		Msg msg = new Msg();
		msg.setmName(App.getName());
		msg.setmIp("255.255.255.255");//广播地址
		msg.setmPort(App.mListenPort);
		msg.setmContent("");
		msg.setmType(Msg.TYPE_OUTLINE);// 下线的广播
		UdpSender.send(msg);
		UdpReceiver.stopReceive();
		super.onDestroy();
	}
	
	@Override
	public void finish() {
		super.finish();
	}
	
}
