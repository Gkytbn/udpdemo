package com.example.net;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import android.util.Log;

import com.example.entity.Msg;

/**
 * UDP发送者，提供向某个主机的某个端口发送UDP数据包
 * @author dxd
 * 20140214
 */
public class UdpSender {
	/**
	 *
	 * @param host 目标主机的名称（IP or 域名）向某主机的某端口发送UDP数据包
	 * @param targetPort 目标主机的端口号
	 * @param sendStr 需发送的数据
	 */
	public static void send(final Msg msg){
		new Thread(){
			@Override
			public void run() {
				if(null == msg){
					return ;
				}
				try {
					String host = msg.getmIp() ;
					int targetPort = msg.getmPort() ;
					byte[] sendBytes = msg.toJson().toString().getBytes("utf-8");
					InetAddress address = InetAddress.getByName (host);
					
					DatagramPacket datapkg = new DatagramPacket(sendBytes, sendBytes.length ,address ,targetPort);
					DatagramSocket client = new DatagramSocket() ;
					Log.e("send","sendBytes = " + new String(sendBytes));
					client.send(datapkg) ;
					System.out.println("send --> "+"send OK !");
				} catch (UnsupportedEncodingException e1) {
					System.out.println("send --> "+"UnsupportedEncodingException");
					e1.printStackTrace();
				} catch (UnknownHostException e) {
					System.out.println("send --> "+"UnknownHostException");
					e.printStackTrace();
				} catch (SocketException e) {
					System.out.println("send"+"SocketException");
					e.printStackTrace();
				} catch (IOException e) {
					System.out.println("send"+"IOException");
					e.printStackTrace();
				}
			}
		}.start();
	}
}
