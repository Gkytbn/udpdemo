package com.example.entity;

import org.json.JSONException;
import org.json.JSONObject;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * 网络发送消息的定义，包含了目标IP和端口号、消息内容等
 * 继承自Parcelable接口，可以用户进程间传递
 * @author dxd
 * 20140312
 */
public class Msg implements Parcelable{
	private String mName ;// 我的名字
	private String mIp ; // 目标Ip
	private int mPort ; // 目标端口号
	private String mContent ; // 消息内容
	private String mType ; // 消息类型
	private String mDate ; // 发送消息的时间戳

	public static String TYPE_NOMAL = "nomal";// 一般的消息，这里暂时默认为文字
	public static String TYPE_RESPONSE = "response" ;// 应答广播
	public static String TYPE_ONLINE = "online" ;// 上线广播
	public static String TYPE_OUTLINE = "outline" ;// 下线广播
	
	public Msg(){
		mName = "null" ;
		mIp = "00:00:00:00";
		mPort = 8080 ;
		mContent = "null" ;
		mType = "null";
		mDate = "00:00:00" ;
	}
	
	public Msg(String name ,String ip ,int port ,String content ,String type ,String date){
		this.mName = name ;
		this.mIp = ip ;
		this.mPort = port ;
		this.mContent = content ;
		this.mType= type ;
		this.mDate = date ;
	}
	
	public JSONObject toJson(){
		JSONObject json = new JSONObject();
		try {
			json.putOpt("name", mName);
			json.putOpt("ip", mIp);
			json.putOpt("port", mPort);
			json.putOpt("content", mContent);
			json.putOpt("type", mType);
			json.putOpt("date", mDate);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json ;
	}
	
	public static Msg toMsg(String JsonStr){
		Msg msg = new Msg();
		try {
			JSONObject json = new JSONObject(JsonStr);
			msg.setmName(json.optString("name"));
			msg.setmIp(json.optString("ip"));
			msg.setmPort(json.optInt("port", 8080));
			msg.setmContent(json.getString("content"));
			msg.setmType(json.getString("type"));
			msg.setmDate(json.getString("date"));
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return msg ;
	}
	
	public String toString(){
		return mName + "\n" + mIp + ":" + mPort + "\n" + mContent + "\ntype = " + mType ;
	}
	public void setmIp(String mIp) {
		this.mIp = mIp;
	}
	public String getmIp() {
		return mIp;
	}
	public int getmPort() {
		return mPort;
	}
	public void setmPort(int mPort) {
		this.mPort = mPort;
	}
	public String getmContent() {
		return mContent;
	}
	public void setmContent(String mContent) {
		this.mContent = mContent;
	}
	public String getmType() {
		return mType;
	}
	public void setmType(String mType) {
		this.mType = mType;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getmDate() {
		return mDate;
	}

	public void setmDate(String mDate) {
		this.mDate = mDate;
	}

	// android中的可序列化，用于线程间的通信
	public static final Parcelable.Creator<Msg> CREATOR = new Creator<Msg>(){  
        @Override  
        public Msg createFromParcel(Parcel source) {  
            // TODO Auto-generated method stub  
            Msg msg = new Msg();
            msg.mName = source.readString();
            msg.mIp = source.readString() ;
            msg.mPort = source.readInt() ;
            msg.mContent = source.readString() ;
            msg.mType = source.readString() ;
            msg.mDate = source.readString();
            return msg;    
        }  
  
        @Override  
        public Msg[] newArray(int size) {  
            return new Msg[size];  
        }    
    }; 
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flag) {
		dest.writeString(mName) ;
		dest.writeString(mIp) ;
		dest.writeInt(mPort);
		dest.writeString(mContent) ;
		dest.writeString(mType) ;
		dest.writeString(mDate);
	}
}
