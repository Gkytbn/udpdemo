package com.example.net;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.net.UnknownHostException;

import android.util.Log;

import com.example.entity.Msg;

/**
 * UDP接收者
 * 提供循环接收某端口的udp数据的方法，并且提供接收数据情况的回调接口。
 * 提供停止监听某个端口的udp数据的方法
 * @author dxd
 * 20140224
 */
public class UdpReceiver {
	private static boolean RUNING = true ;
	private static DatagramSocket client ;
	/**
	 * 接收UDP数据的回调接口，用于监听数据接收成功和数据接收异常
	 */
	public interface IReceiveListener {
		public void receivedMsg(Msg msg);
		public void occuredException(String exStr);
	}
	
	/**
	 * 开始循环监听某个端口，内部开了线程。在调用时，不需要另开线程。
	 * @param port UDP监听的端口号
	 * @param pListener 接收UDP数据的回调接口
	 */
	public static void startReceive(final int pPort ,final IReceiveListener pListener) {
		new Thread(){
			@Override
			public void run() {
				System.out.println("Receive --> "+"start to listen , prot =" + pPort);
				try {
					client = new DatagramSocket(pPort);
				} catch (SocketException e1) {
					pListener.occuredException("SocketException	! new DatagramSocket() exception");
				}
				while (RUNING && !client.isClosed()) {
					byte[] getBytes = new byte[1024];
					try {
						DatagramPacket datapkg = new DatagramPacket(getBytes,getBytes.length);
						client.receive(datapkg);
						
						byte[] receiveBytes = datapkg.getData();
						int receiveLength = datapkg.getLength();
						String hostStr = datapkg.getAddress().getHostAddress() ;
						int port = datapkg.getPort() ;
						String receiveStr = new String(receiveBytes, 0, receiveLength,"utf-8");
						Log.e("","receiveStr = " + receiveStr);
						Msg msg = Msg.toMsg(receiveStr);
						msg.setmIp(hostStr);
						msg.setmPort(port);
						pListener.receivedMsg(msg);
					} catch (UnknownHostException e) {
						RUNING = false;
						pListener.occuredException("UnknownHostException");
					} catch (SocketException e) {
						RUNING = false;
						pListener.occuredException("SocketException");
					} catch (IOException e) {
						RUNING = false;
						pListener.occuredException("IOException");
					}
				}
			}
		}.start();
	}
	
	/**
	 * 停止UDP监听某个端口
	 */
	public static void stopReceive(){
		RUNING = false ;
		if(null != client){
			client.disconnect() ;
		}
	}
}
